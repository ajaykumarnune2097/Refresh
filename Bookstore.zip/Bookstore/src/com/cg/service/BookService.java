package com.cg.service;

import com.cg.dao.BookDao;

@Transactional
@Service
public interface BookService {
	
	@Autowired
	BookDao bookDao;

}
