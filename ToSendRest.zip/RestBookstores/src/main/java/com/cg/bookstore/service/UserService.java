package com.cg.bookstore.service;

import java.util.List;

import com.cg.bookstore.beans.UserTable;

public interface UserService {
	public List<UserTable> getUsers();
}
