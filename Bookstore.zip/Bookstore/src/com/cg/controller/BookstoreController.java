package com.cg.controller;

import com.cg.service.BookService;

@Controller
public class BookstoreController {
	
	@Autowired
	BookService bookService;
	

}
