package com.cg.bookstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bookstore.beans.UserName;
@Repository("userDao")
public class UserDaoImpl implements UserDao{

	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public List<UserName> getAllUser() {
		// TODO Auto-generated method stub
	//	Query q= entityManager.createQuery("from usertable");
		TypedQuery<UserName> query=entityManager.createQuery("select q from UserName q",UserName.class);
		return query.getResultList();
	//	return q.getResultList();
		
}


	@Override
	public boolean save(UserName user) {
		// TODO Auto-generated method stub
		if(findEmail(user.getEmail())!=null){
			return false;
		}else {
			entityManager.persist(user);
		return false;
		}
	}


	@Override
	public UserName findEmail(String email) {
		// TODO Auto-generated method stub
		UserName user=null;
		Query q=entityManager.createQuery("from UserName c where c.email=?1");
		q.setParameter(1, email);
		q.setMaxResults(1);
		List<UserName> list=q.getResultList();
		if(list.size()>0) {
			System.out.println("user it enter "+list.get(0));
			user=list.get(0);
		}
		if(user != null) {
			return user;
		}
		return null;
	}


	@Override
	public UserName getId(int id) {
		// TODO Auto-generated method stub
		UserName user=null;
		Query r=entityManager.createQuery("from UserName c where c.userId=?1");
		r.setParameter(1,id );
		r.setMaxResults(1);
		List<UserName> list=r.getResultList();
		if(list.size()>0) {
			user=list.get(0);
		}
		if(user != null) {
			return user;
		}
		return null;
	}


	@Override
	public boolean update(UserName user) {
		// TODO Auto-generated method stub
		entityManager.merge(user);
		return true;
	}
	
}
