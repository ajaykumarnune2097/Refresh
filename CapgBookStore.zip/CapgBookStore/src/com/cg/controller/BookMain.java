package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.service.BookServiceImpl;
import com.cg.service.IBookService;

@Controller
public class BookMain {

	@Autowired
	IBookService iBookService;
	
	@RequestMapping("/index")	
	public String add()
	{
		//System.out.println("12");
		//IBookService iBookService=new BookServiceImpl();
		iBookService.allBooks();
		//System.out.println("123");
		return "login";
	}
	
}
