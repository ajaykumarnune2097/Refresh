export class User{
	userId : number;
	email : string;
	name : string;
	password : string;
}