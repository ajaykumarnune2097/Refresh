package com.cg.dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.entities.Books;

@Repository
public class BookDaoImpl implements IBookDao{

	
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void allBooks() {
		
		
		Books book1=new Books("story","book1","manoj koteda","description","asd123587","image1", 12.0f, LocalDate.now());
		
		entityManager.persist(book1);
		System.out.println("1");
	}
	
	
	
}
