package com.cg.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.bookstore.dao.UserDao;

public class UserServiceImpl {

	@Autowired
	UserDao userDao;
}
