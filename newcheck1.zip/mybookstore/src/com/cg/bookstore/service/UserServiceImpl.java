package com.cg.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bookstore.beans.UserName;
import com.cg.bookstore.dao.UserDao;
@Service("userService")
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao userDao;

	@Override
	public List<UserName> getAllUser() {
		// TODO Auto-generated method stub
		
		return userDao.getAllUser();
	}
	
}
