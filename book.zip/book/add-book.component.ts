import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { Books } from '../models/book.model';
import { BookService } from './book.service';

@Component({
	templateUrl: './add-book.component.html'
})
export class AddBookComponent {
	
	book: Books=new Books();
	
	constructor(private router: Router, private bookService: BookService) {
	}
	
	createBook(): void {
		this.bookService.createBook(this.book)
		.subscribe( data => { alert("Book created successfully.");
		});
	};
}