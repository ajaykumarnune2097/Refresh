import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { Books } from '../models/book.model';
import { BookService } from './book.service';

@Component({
	templateUrl: './add-book.component.html',
	styleUrls: ['./book.component.css']
})
export class AddBookComponent {
	
	book: Books=new Books();
	
	constructor(private router: Router, private bookService: BookService) {
	}
	
	createBook(): void {
		if(this.book.category == null){
			alert("Category can't be empty");
			return;
		}
		if(this.book.title == null){
			alert("Title can't be empty");
			return;
		}
		if(this.book.author == null){
			alert("Author can't be empty");
			return;
		}
		if(this.book.description == null){
			alert("Description can't be empty");
			return;
		}
		if(this.book.isbnNumber == null){
			alert("ISBN Number can't be empty");
			return;
		}
		if(this.book.imageFileName == null){
			alert("Image can't be empty");
			return;
		}
		if(this.book.price == null){
			alert("Price can't be empty");
			return;
		}
		if(this.book.publishDate == null){
			alert("Publich Date can't be empty");
			return;
		}
		this.bookService.createBook(this.book)
		.subscribe( data => { alert("Book created successfully.");
		 this.router.navigate(['books']);
		});
	};
}