package com.cg.bookstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.cg.bookstore.beans.UserTable;
@Repository("userDao")
public interface UserDao extends JpaRepository<UserTable, Integer>{
	List<UserTable> findAll();
}
