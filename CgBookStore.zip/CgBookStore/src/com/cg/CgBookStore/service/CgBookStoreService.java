package com.cg.CgBookStore.service;

import com.cg.CgBookStore.entities.User;

public interface CgBookStoreService {

	

	public User createUser(User user);

}
