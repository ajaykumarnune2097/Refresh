package com.cg.StoreBook.service;

public interface BookStoreService {

	public void listOfAllBooks();

}
