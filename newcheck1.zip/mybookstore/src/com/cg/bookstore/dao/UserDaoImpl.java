package com.cg.bookstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bookstore.beans.UserName;
@Repository("userDao")
public class UserDaoImpl implements UserDao{

	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public List<UserName> getAllUser() {
		// TODO Auto-generated method stub
	//	Query q= entityManager.createQuery("from usertable");
		TypedQuery<UserName> query=entityManager.createQuery("select q from usertable q",UserName.class);
		return query.getResultList();
	//	return q.getResultList();
		
}
}
