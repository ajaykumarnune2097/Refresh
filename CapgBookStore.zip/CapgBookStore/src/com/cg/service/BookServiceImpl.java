package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.BookDaoImpl;
import com.cg.dao.IBookDao;

@Service
@Transactional
public class BookServiceImpl implements IBookService{


	
	@Autowired
	IBookDao iBookDao;
	//IBookDao iBookDao=new BookDaoImpl();
	
	@Override
	public void allBooks() {
		
		//System.out.println("12");
		iBookDao.allBooks();
		
	}

}
