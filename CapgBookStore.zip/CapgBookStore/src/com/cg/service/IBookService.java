package com.cg.service;

public interface IBookService {

	public void allBooks();
	
}
