package com.cg.bookstore.service;

import java.util.List;

import com.cg.bookstore.beans.UserName;

public interface UserService {

	public List<UserName> getAllUser();
	
	public boolean save(UserName user);
	
	public UserName findEmail(String email);
	
	public UserName getId(int id);
	public boolean update(UserName user);
}
