import { Component } from '@angular/core';

@Component({
  templateUrl: './customer.component.html'
})
export class CustomerComponent {
}
