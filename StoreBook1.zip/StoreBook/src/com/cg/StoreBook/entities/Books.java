package com.cg.StoreBook.entities;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Books implements Serializable{
	
	@Id
	private int bookId;
	private String category; 
	private String title; 
	private String author; 
	private String description; 
	private String isbnNumber; 
	private String imageFileName; 
	private float price; 
	private LocalDate publishDate;
	
public Books() {
		
		
	}
	
	public Books(int bookId,String category, String title, String author, String description, String isbnNumber,
			String imageFileName, float price, LocalDate publishDate) {
		super();
		this.bookId = bookId;
		this.category = category;
		this.title = title;
		this.author = author;
		this.description = description;
		this.isbnNumber = isbnNumber;
		this.imageFileName = imageFileName;
		this.price = price;
		this.publishDate = publishDate;
	}
	
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIsbnNumber() {
		return isbnNumber;
	}
	public void setIsbnNumber(String isbnNumber) {
		this.isbnNumber = isbnNumber;
	}
	public String getImageFileName() {
		return imageFileName;
	}
	public void setImageFileName(String imageFileName) {
		this.imageFileName = imageFileName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public LocalDate getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(LocalDate publishDate) {
		this.publishDate = publishDate;
	}
	@Override
	public String toString() {
		return "Books [bookId=" + bookId + ", category=" + category + ", title=" + title + ", author=" + author
				+ ", description=" + description + ", isbnNumber=" + isbnNumber + ", imageFileName=" + imageFileName
				+ ", price=" + price + ", publishDate=" + publishDate + "]";
	}
	
	

}
