package com.cg.StoreBook.dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.StoreBook.entities.Books;

@Repository
public class BookStoreDaoImpl implements BookStoreDao{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void listOfAllBooks() {
		// TODO Auto-generated method stub
		Books books=new Books(1,"Sports","Loose To Win","Ajay","Description","ISBNO12","Imgname",12.3f,LocalDate.now());
		entityManager.persist(books);
	}

	
}
