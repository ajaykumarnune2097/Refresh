package com.cg.bookstore.RestBookstores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories(basePackages="com.cg.bookstore.*")
@ComponentScan(basePackages="com.cg.bookstore.*")
@EntityScan(basePackages="com.cg.bookstore.*")
@EnableAutoConfiguration 
public class RestBookstoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestBookstoresApplication.class, args);
	}

}
