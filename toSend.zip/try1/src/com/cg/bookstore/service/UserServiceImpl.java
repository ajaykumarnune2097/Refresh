package com.cg.bookstore.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bookstore.beans.UserName;
import com.cg.bookstore.dao.UserDao;
@Transactional
@Service("userService")
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao userDao;

	@Override
	public List<UserName> getAllUser() {
		// TODO Auto-generated method stub
		
		return userDao.getAllUser();
	}

	@Override
	public boolean save(UserName user) {
		// TODO Auto-generated method stub
		return userDao.save(user);
	}

	@Override
	public UserName findEmail(String email) {
		// TODO Auto-generated method stub
		return userDao.findEmail(email);
	}

	@Override
	public UserName getId(int id) {
		// TODO Auto-generated method stub
		return userDao.getId(id);
	}

	@Override
	public boolean update(UserName user) {
		// TODO Auto-generated method stub
		return userDao.update(user);
	}
	
	
	
}
