package com.cg.bookstore.dao;

public class UserDaoImpl {

}
