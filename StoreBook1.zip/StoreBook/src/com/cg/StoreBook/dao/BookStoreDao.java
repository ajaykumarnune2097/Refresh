package com.cg.StoreBook.dao;

public interface BookStoreDao {

	public void listOfAllBooks();

}
