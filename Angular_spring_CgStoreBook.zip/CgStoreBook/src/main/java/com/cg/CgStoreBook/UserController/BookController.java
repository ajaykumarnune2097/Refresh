package com.cg.CgStoreBook.UserController;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CgStoreBook.entities.Books;
import com.cg.CgStoreBook.service.CgStoreBookService;

import net.bytebuddy.asm.Advice.Origin;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/rest")
public class BookController {

	@Autowired
	CgStoreBookService  cgBookStoreService; 

	
	@RequestMapping("/index")
	public String index(Model model) {
	
		System.out.println("sdfdsvgasdgadfgasdf");
		return "dsfkjaesghfkurewgfghfjaewghfrgf";
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.POST,value = "/new")
	public Books newBook(@RequestBody Books book) {
		//Books books=new Books("Sports", "Chase to Win", "Sai Nath", "A boy with one eye ...... and then chased and won!!", "ISBN001", "sport.jpg", 120, LocalDate.now());
		cgBookStoreService.newBook(book);
		return book;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET,value="/list")
	public List<Books> listAll() {
		return cgBookStoreService.listAll();
		
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.DELETE,value="/delete/{bookId}")
	public void deleteBook(@PathVariable int bookId) {
		cgBookStoreService.deleteBook(bookId);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.POST,value = "/edit/{bookId}")
	public Books editBook(@PathVariable int bookId,@RequestBody Books book) {
		//Books books=new Books("Sports", "Chase to Win", "Sai Nath", "A boy with one eye ...... and then chased and won!!", "ISBN001", "sport.jpg", 120, LocalDate.now());
		cgBookStoreService.editBook(book);
		return book;
	}
}


