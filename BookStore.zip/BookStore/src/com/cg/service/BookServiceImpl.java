package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BookDao;

@Transactional
@Service
public class BookServiceImpl implements BookService{

	@Autowired
	BookDao bookDao;
}
