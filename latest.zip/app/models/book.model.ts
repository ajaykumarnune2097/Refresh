export class Books {
	bookId: number;
	category: string; 
	title: string; 
	author: string; 
	description: string; 
	isbnNumber: string; 
	imageFileName: string; 
	price: number; 
	publishDate: string;
}