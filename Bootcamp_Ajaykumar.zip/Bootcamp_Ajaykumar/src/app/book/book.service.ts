import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Books } from '../models/book.model';

const httpOptions = {
	headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class BookService {
	
	constructor(private http:HttpClient) {}
	
	private bookUrl = 'http://localhost:8088/rest/list';
	
	private createUrl= 'http://localhost:8088/rest/new';
	
	private deleteUrl= 'http://localhost:8088/rest/delete';
	
	private editUrl = 'http://localhost:8088/rest/edit';
	
	public getBooks() {
		return this.http.get<Books[]>(this.bookUrl);
	}	
	
	public createBook(book) {
		
		return this.http.post(this.createUrl, book);
	}
	
	 public deleteBook(book) {
    return this.http.delete(this.deleteUrl + "/"+ book.bookId);
    }
	
	/*public editBook(book) {
		return this.http.post(this.editUrl + "/"+book);
	}*/
	
	/* updateBook(book: Ibook) {
    return this.http.post(this._url+"/"+"update",book);
  }*/
}