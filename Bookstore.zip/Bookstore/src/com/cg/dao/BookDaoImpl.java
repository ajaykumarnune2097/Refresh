package com.cg.dao;

public class BookDaoImpl implements BookDao{
	
	@Persistancecontext
	EntityManager entityManager;

}
