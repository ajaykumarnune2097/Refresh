package com.cg.dao;

public interface IBookDao {

	public void allBooks();
	
}
