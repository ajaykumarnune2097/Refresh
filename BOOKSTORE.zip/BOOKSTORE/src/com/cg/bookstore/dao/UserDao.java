package com.cg.bookstore.dao;

public interface UserDao {

}
