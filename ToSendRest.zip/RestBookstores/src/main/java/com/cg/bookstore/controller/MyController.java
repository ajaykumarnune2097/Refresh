package com.cg.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bookstore.beans.UserTable;
import com.cg.bookstore.service.UserService;

@RestController
@RequestMapping("/rest")
public class MyController {
	
	@Autowired
	UserService userService;
	
	@RequestMapping("/viewAll")
	public List<UserTable> viewAllUsers() {
		List<UserTable> list=userService.getUsers();
		return list;
	}
}
