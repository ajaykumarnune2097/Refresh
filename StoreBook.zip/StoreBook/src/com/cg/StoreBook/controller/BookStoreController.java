package com.cg.StoreBook.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.StoreBook.service.BookStoreService;

@Controller
public class BookStoreController {
	
	@Autowired
	BookStoreService bookStoreService;
	
	@RequestMapping
	public String index() {
		bookStoreService.listOfAllBooks();
		 return "index";
	}
}
