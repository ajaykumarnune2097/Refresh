package com.cg.CgBookStore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.CgBookStore.dao.CgBookStoreDao;
import com.cg.CgBookStore.entities.User;

@Transactional
@Service
public class CgBookStoreServiceImpl implements CgBookStoreService {
	
	@Autowired
	CgBookStoreDao cgBookStoreDao;

	

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return cgBookStoreDao.createUser(user);
	}
}
