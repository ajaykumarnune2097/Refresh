package com.cg.StoreBook.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.StoreBook.dao.BookStoreDao;

@Transactional
@Service
public class BookStoreServiceImpl implements BookStoreService{
	
	@Autowired
	BookStoreDao bookStoreDao;

	@Override
	public void listOfAllBooks() {
		// TODO Auto-generated method stub
		bookStoreDao.listOfAllBooks();
	}

}
