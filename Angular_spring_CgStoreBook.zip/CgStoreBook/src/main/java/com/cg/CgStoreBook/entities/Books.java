package com.cg.CgStoreBook.entities;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Books")
@Component
public class Books {
	 
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bookId;
	@NotNull
	private String category;
	@NotNull
	@Size(min=10,max=128)
	private String title;
	@NotNull
	@Size(min=5,max=64)
	private String author;
	@NotNull
	@Size(min=20,max=200)
	private String description;
	@NotNull
	@Size(min=10,max=15)
	private String isbnNumber;
	@NotNull
	private String imageFileName;
	@NotNull
	private int price;
	@NotNull
	private LocalDate publishDate;
	
public Books() {
		
		
	}
	
	public Books(String category, String title, String author, String description, String isbnNumber,
			String imageFileName, int price, LocalDate publishDate) {
		super();
		this.category = category;
		this.title = title;
		this.author = author;
		this.description = description;
		this.isbnNumber = isbnNumber;
		this.imageFileName = imageFileName;
		this.price = price;
		this.publishDate = publishDate;
	}
	
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIsbnNumber() {
		return isbnNumber;
	}
	public void setIsbnNumber(String isbnNumber) {
		this.isbnNumber = isbnNumber;
	}
	public String getImageFileName() {
		return imageFileName;
	}
	public void setImageFileName(String imageFileName) {
		this.imageFileName = imageFileName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public LocalDate getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(LocalDate publishDate) {
		this.publishDate = publishDate;
	}
	
	
	@Override
	public String toString() {
		return "Books [bookId=" + bookId + ", category=" + category + ", title=" + title + ", author=" + author
				+ ", description=" + description + ", isbnNumber=" + isbnNumber + ", imageFileName=" + imageFileName
				+ ", price=" + price + ", publishDate=" + publishDate + "]";
	}
	
	
	

}
