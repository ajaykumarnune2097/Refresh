package com.cg.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bookstore.beans.UserTable;
import com.cg.bookstore.dao.UserDao;
@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	UserDao userdao;
	
	public List<UserTable> getUsers() {
		
	//	List<User>list= userdao.findAll();
	//	return list;
		return userdao.findAll();
	}
	
}
