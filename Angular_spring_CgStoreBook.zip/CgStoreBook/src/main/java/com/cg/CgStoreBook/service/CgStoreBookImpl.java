package com.cg.CgStoreBook.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.CgStoreBook.dao.CgStoreBookDao;
import com.cg.CgStoreBook.entities.Books;


@Transactional
@Service("cgBookStoreService")
public class CgStoreBookImpl implements CgStoreBookService{
	
	@Autowired
	CgStoreBookDao cgStoreBookDao;

	@Override
	public Books newBook(Books book) {
		// TODO Auto-generated method stub
		return cgStoreBookDao.save(book);
	}

	@Override
	public List<Books> listAll() {
		// TODO Auto-generated method stub
		return cgStoreBookDao.findAll();
	}

	@Override
	public void deleteBook(int bookId) {
		// TODO Auto-generated method stub
		cgStoreBookDao.deleteById(bookId);
	}

	@Override
	public Books editBook(Books book) {
		// TODO Auto-generated method stub
		return cgStoreBookDao.save(book);
	}

	

}
