package com.cg.CgStoreBook.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.CgStoreBook.entities.Books;

public interface CgStoreBookService {

	public Books newBook(Books book);

	public List<Books> listAll();

	public void deleteBook(int bookId);

	public Books editBook(Books book);

	
	/* public User createUser(User user); */

	

}
