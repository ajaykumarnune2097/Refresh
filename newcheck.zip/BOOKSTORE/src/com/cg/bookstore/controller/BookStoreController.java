package com.cg.bookstore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bookstore.beans.UserName;
import com.cg.bookstore.service.UserService;

@Controller
public class BookStoreController {
 
	@Autowired
	UserService userService;
	
	
	
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@RequestMapping("/viewuser")
	/*public String viewUser(Model m) {
		List<UserName> list=userService.getAllUser();
		m.addAttribute("list", list);
		return "viewuser";
	}*/
	
	public ModelAndView viewUser(HttpServletRequest request) {
		ModelAndView view=new ModelAndView();
		List<UserName> list=userService.getAllUser();
		HttpSession session = request.getSession();
		session.setAttribute("list", list);
		return view;
	}
	
	
	
}
