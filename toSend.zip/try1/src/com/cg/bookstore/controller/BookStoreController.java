package com.cg.bookstore.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bookstore.beans.UserName;
import com.cg.bookstore.service.UserService;

@Controller
public class BookStoreController {

	@Autowired
	UserService userService;

	@Autowired
	UserName user;

	@RequestMapping("/index")
	public String index() {
		return "index";
	}

	@RequestMapping("/view")
	public String viewUser(Model m) {
		m.addAttribute("list", userService.getAllUser());
		return "view";
	}

	@RequestMapping(value = "/Edit")
	public ModelAndView Edit(@RequestParam("id") int id) {
		
		ModelAndView view = new ModelAndView("editform");

		UserName user = userService.getId(id);
		System.out.println(user);
		view.addObject("user", user); 
		view.setViewName("editform");
		return view;

	}

	@RequestMapping(value = "/editsave", method = RequestMethod.POST)
	public String SaveEdit(@ModelAttribute("user") UserName user) {
		userService.update(user);
		return "index";
	}
}
