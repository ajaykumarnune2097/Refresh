
package com.cg.CgBookStore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.CgBookStore.entities.User;

@Repository
public class CgBookStoreDaoImpl implements CgBookStoreDao{
 @PersistenceContext
 EntityManager entityManager;
 
 
	@Override
	public User createUser(User user) {
		entityManager.persist(user);
		entityManager.flush();
		return user;
	}

}
