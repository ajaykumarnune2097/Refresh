package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class BookDaoImpl {
	
	@PersistenceContext
	EntityManager entityManager;

}
