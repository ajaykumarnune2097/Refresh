package com.cg.service;

public class BookServiceImpl implements BookService{

}
