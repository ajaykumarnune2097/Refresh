package com.cg.CgBookStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.CgBookStore.entities.User;
import com.cg.CgBookStore.service.CgBookStoreService;

@Controller
public class CgBookStoreController {
	
	@Autowired
	CgBookStoreService  cgBookStoreService; 

	
	@RequestMapping("/index")
	public String index(Model model) {
	
		
		return "index";
		
	}
	@RequestMapping("/create")
	public String createUser(Model model) {
		model.addAttribute("create",new User() );
	
		
		return "createUser";
		
	}
	@RequestMapping("/new")
	public String newUser(@ModelAttribute("create") User user, Model model) {
		
		cgBookStoreService.createUser(user);	
		return "index";
		
	}
	
}

