package com.cg.bookstore.dao;

import java.util.List;

import com.cg.bookstore.beans.UserName;

public interface UserDao {

	public List<UserName> getAllUser();
}
