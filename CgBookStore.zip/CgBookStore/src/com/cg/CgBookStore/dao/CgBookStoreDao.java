package com.cg.CgBookStore.dao;

import com.cg.CgBookStore.entities.User;

public interface CgBookStoreDao {

	public User createUser(User user);

}
