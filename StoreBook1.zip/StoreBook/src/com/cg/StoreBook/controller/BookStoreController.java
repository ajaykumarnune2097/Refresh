package com.cg.StoreBook.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.StoreBook.service.BookStoreService;

@Controller
public class BookStoreController {
	
	@Autowired
	BookStoreService bookStoreService;
	
	@RequestMapping("/index")
	public String index(Model model) {
		System.out.println("1");
		bookStoreService.listOfAllBooks();
		 return "index";
	}
}
