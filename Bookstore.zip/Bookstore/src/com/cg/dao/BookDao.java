package com.cg.dao;

public interface BookDao {

}
